# [앱바] 앱테크 아이콘 모션 — 인터랙션 정의

앱바 오른쪽 **앱테크 아이콘(로티)** 과 그 왼쪽 **이벤트 아이콘(체크인) 배지**의 인터랙션 기준입니다.

- 프로토타입: `Type_1.html`
- Figma: https://www.figma.com/design/o0jTKUbX15ampUa9e8VUEP/MDS-2.0-%EB%B3%80%EA%B2%BD-%EB%A1%9C%EA%B7%B8-%EA%B3%B5%EC%9C%A0?node-id=9373-12156&t=Xd5vaxGnlqC6HeJw-4
- Jira: https://jira.team.musinsa.com/browse/PD-10142
- 기준 코드: `src/types/type_1.js`, `src/types/type_1.css`
- 수정일: 2026-11-12

---

## 1. 앱테크 아이콘 로티 파일

전문관 스토어별 **아이콘 색상에 맞춘** 로티 파일을 적용합니다. 배경이 투명해서 광고판 진입·이탈 때도 같은 파일을 끊김 없이 그대로 재생합니다.

| 파일 | 아이콘 색 | 적용 화면 |
|---|---|---|
| `ic_appbar_apptech_white.json` | 흰색 | 무신사, 뷰티, 아울렛, 부티크, 킥스 |
| `ic_appbar_apptech_black.json` | 검정 | 스포츠, 유즈드, **마이 페이지** |
| `ic_appbar_apptech_kids.json` | 키즈 주황 `#FF5F00` | 키즈 |

- 위치: `src/lottie/`
- 규격: 84 × 84 (화면 표시 28 × 28), 30fps, 291프레임(약 9.7초), 반복 재생
- 마이 페이지도 앱바 아이콘이 검정이므로 black 버전을 적용합니다. (프로토타입에는 마이 페이지 화면이 없습니다.)

## 2. 앱테크 아이콘 재생 타이밍

재생 기준은 왼쪽 이벤트 아이콘(체크인)이 있는지 여부입니다.

| 경우 | 재생 시작 | 이후 |
|---|---|---|
| 이벤트 아이콘 **있음** | 랜딩 직후에는 첫 프레임에서 정지. 이벤트 아이콘의 배지가 **opacity로 완전히 사라진 순간** 재생 시작 | 루핑 재생. 배지가 사라질 때마다 0프레임부터 다시 재생 |
| 이벤트 아이콘 **없음** | **랜딩하자마자** 0프레임부터 재생 | 루핑 재생 |

- 랜딩: 화면 진입, 스토어 전환.
- 로티 한 바퀴(약 9.7초)는 배지 한 바퀴(등장 + 노출 3초 + 사라짐 0.15초 + 대기 6초)와 거의 같습니다. 조금씩 어긋나지 않도록, 배지가 사라질 때마다 0프레임으로 맞춥니다. 배지가 다시 등장할 때는 로티를 건드리지 않습니다.

## 3. 이벤트 아이콘(체크인) 배지 모션

"이벤트" 배지가 체크인 아이콘 오른쪽 위에서 나타났다 사라지기를 반복합니다.

| 항목 | 값 |
|---|---|
| 대상 | 체크인 아이콘의 "이벤트" 배지 |
| 모션 중심점 | 배지 **좌하단** (`transform-origin: 0 100%`) |
| 첫 딜레이 | 랜딩 후 **1초** |
| 등장 | scale `0 → 1` · `mds.spring.bouncy` / opacity `0 → 1` · linear 0.15s |
| 노출 | 등장 모션이 끝난 뒤 **3초** |
| 사라짐 | scale `1 → 0` · `mds.spring.bouncy` / opacity `1 → 0` · linear 0.15s |
| 재등장 | 완전히 사라지고 **6초** 후 다시 등장 |
| 반복 | 등장 → 노출 → 사라짐 → 대기를 계속 반복 |

- "완전히 사라짐"은 opacity가 0이 된 시점(사라짐 시작 후 0.15초)입니다. scale 스프링이 끝나기를 기다리지 않습니다. 앱테크 로티 재생도 이 시점에 시작합니다.
- 스토어를 바꾸면 배지 모션은 처음부터(1초 딜레이부터) 다시 시작합니다.

```js
// 웹 (Motion)
const spring = { type: 'spring', stiffness: 322, damping: 26 }; // mds.spring.bouncy
// 등장
Motion.animate(badge, { scale: [0, 1], opacity: [0, 1] }, {
  scale: spring,
  opacity: { duration: 0.15, ease: 'linear' }
});
// 사라짐
Motion.animate(badge, { scale: [1, 0], opacity: [1, 0] }, {
  scale: spring,
  opacity: { duration: 0.15, ease: 'linear' }
});
```

### 배지 모양

| 항목 | 값 |
|---|---|
| 위치 | 체크인 아이콘(28 칸) 기준 x 15, y -2 |
| 크기 | 높이 13, 최소 너비 16, 여백 1.5 / 3, 둥글기 18 |
| 글자 | "이벤트" · Pretendard Medium 8px |

### 배지 색

| 화면 | 바탕 | 글자 |
|---|---|---|
| 무신사 | `#245EFF` | 흰색 |
| 뷰티, 킥스, 부티크, 아울렛 | 흰색 | 스토어 색 |
| 스포츠 | 스토어 색 | 흰색 |
| 키즈 | 스토어 색 | `#3734B8` (키즈 헤더색) |
| 유즈드 | `#000` | 흰색 |
| 광고판 진입 (스포츠·유즈드·키즈 제외) | 흰색 | 광고 색 |

앱테크 아이콘 닷과 알림(종) 아이콘 닷(4px)도 배지 바탕과 같은 색 규칙을 따릅니다.

## 4. 모션 값

- 가이드 링크: https://www.figma.com/design/oSeWgRf3JXSk6AvrceXTUN/MDS-2.0-Specimen?node-id=18455-38812&t=0cmppl22KL0yQlLQ-4

| 토큰 | 웹(stiffness / damping) | iOS(duration / dampingRatio) | Android(stiffness / dampingRatio) |
|---|---|---|---|
| `mds.spring.bouncy` | 322 / 26 | 0.5s / 0.75 | 600 / 0.75 |

## 5. 변수 목록 (`type_1.css` · `.appbar-checkin-badge`)

| 변수 | 값 | 내용 |
|---|---|---|
| `--checkin-badge-first-delay` | 1s | 랜딩 후 첫 등장까지 |
| `--checkin-badge-show` | 3s | 등장 모션이 끝난 뒤 노출 시간 |
| `--checkin-badge-hide` | 6s | 완전히 사라진 뒤 다시 등장까지 |
| `--checkin-badge-fade` | 0.15s | opacity linear 시간 |
| `--checkin-badge-spring-stiffness` / `-damping` | 322 / 26 | scale `mds.spring.bouncy` |

## 6. 프로토타입 전용 (실제 앱 UI 아님)

- **스토어 · 이벤트 아이콘 옵션:** 인덱스(`index.html`) 오른쪽 OPTIONS 카드에서 바꿉니다. 프로토타입 페이지만 열면 데스크탑은 폰 오른쪽 창, 모바일은 빅배너 위 가로 줄에서 바꿉니다.
- **이벤트 아이콘:** 끄면 체크인 아이콘이 없는 경우를 보여주고, 로티는 2장의 "없음" 규칙으로 재생합니다.
- **QR 주소:** 고른 값이 `?opt-store=값&opt-checkin=on|off`로 붙습니다.

## 7. 구현 시 확인할 점

- **마이 페이지:** 프로토타입에 화면이 없어 black 버전 적용을 직접 확인하지 못했습니다.
- **백그라운드 탭:** 브라우저는 숨은 탭에서 타이머와 애니메이션을 늦춥니다. 앱으로 돌아왔을 때 배지와 로티 타이밍을 처음부터 다시 맞출지 정해야 합니다.
- **접근성:** 모션 줄이기 설정을 켠 사용자에게 배지 반복과 로티 루프를 멈출지 정해야 합니다.
