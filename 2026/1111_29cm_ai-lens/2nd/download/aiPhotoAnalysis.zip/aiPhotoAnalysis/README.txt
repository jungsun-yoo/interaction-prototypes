AI 렌즈 프로토타입 — aiPhotoAnalysis
만든 날: 2026-11-17

- index.html 을 브라우저로 열면 됩니다 (Chrome · Safari).
- 인터랙션 명세: interaction.md
- 조절 값: values.css (명세 절 순서와 같음)
- shared/: 다른 프로토타입과 같이 쓰는 공용 파일 (MDS 모션 토큰, AI 로딩 아이콘)
- 옵션창 · QR 동기화(프로토타입 전용)는 뺐습니다. 새로고침하면 처음부터 다시 재생됩니다.
