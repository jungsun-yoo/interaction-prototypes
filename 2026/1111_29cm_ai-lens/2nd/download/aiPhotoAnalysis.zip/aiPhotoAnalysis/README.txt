AI 렌즈 프로토타입 — aiPhotoAnalysis
만든 날: 2026-11-24

- index.html 을 브라우저로 열면 됩니다 (Chrome · Safari).
- 인터랙션 명세: interaction.md
- 조절 값: css/values.css (명세 절 순서와 같음)
- shared/: 다른 프로토타입과 같이 쓰는 공용 파일 (MDS 모션 토큰, AI 로딩 아이콘)
- 새로고침하면 처음부터 다시 재생됩니다 (옵션 카드 · QR 동기화는 인덱스 전용이라 들어 있지 않음).
