무신사 렌즈 프로토타입
만든 날: 2026-11-24

- prototype/aiPhotoAnalysis/index.html: AI 사진 분석 (분석 중 → 분석 완료)
- 인터랙션 가이드: prototype/aiPhotoAnalysis/aiPhotoAnalysis_interaction-guide.md
- 조절 값: prototype/aiPhotoAnalysis/css/values.css (가이드 절 순서와 같음)
- prototype/src/: 같이 쓰는 공용 파일 (MDS 모션 토큰, AI 로딩 아이콘)
- html 파일을 브라우저(Chrome · Safari)로 열면 됩니다.
- AI 사진 분석은 6초 뒤 결과 화면으로 넘어가고, 새로고침하면 처음부터 다시 재생됩니다 (옵션 카드 · QR 동기화는 인덱스 전용이라 들어 있지 않음).
